let x = 100;// type inference
//x = "Hello !";

// type annotations
let y:number;
y = 200;

let str:string = "Typescript !";
let boolVar:boolean = true;
let z:any;
z = "ABC";
z = 100;

// Functions

function Add(x:number,y:number):number{
   return x + y;
}

let result:number = Add(20,30);

// Enumerations

enum Designations {
    Developer = 100, //0
    Trainer = 200,
    Tester,
    Manager,
    Architect
}

let desgn:Designations;

desgn = Designations.Trainer;
//desgn = "Hello !";

console.log(desgn);// numeric Value
console.log(Designations[desgn]); // Symbolic Value

// Arrays

// let cars:string[]; // decl
// cars = ['BMW','Audi','Honda','Hyundai'];

// OR

let moreCars:Array<string>; // Generics
moreCars = new Array<string>('Fiat','Merc','Ferrari');

// for(let car in cars){
//     console.log(cars[car]);
// }

// for(let car of cars){
//     console.log(car);
// }

let arrayOfObjects:any[];

arrayOfObjects = [
    {Name:'Fiserv',Location:'Pune'},
    {Name:'Accenture',Location:'Mumbai'},
    {Name:'Synechron',Location:'Hyderabad'} 
];

for(let company of arrayOfObjects){
    console.log(company.Name + " is in " + company.Location)
}


enum Category{
    Motivational = 200,
    Biography,
    Fiction
}

function GetAllBooks():any[]{
        let allBooks:any[];
        allBooks = [
            {Title:'Playing It My Way',Author:'Sachin Tendulkar',Available:true,Price:2000,Category:Category.Biography},
            {Title:'Wings Of Fire',Author:'Dr. APJ Abdul Kalam',Available:true,Price:1000,Category:Category.Motivational},
            {Title:'Mrutyunjay',Author:'Ranjit Desai',Available:true,Price:2000,Category:Category.Fiction},
            {Title:'Radhey',Author:'Ranjit Desai',Available:true,Price:4000,Category:Category.Fiction}
            
        ];
        return allBooks;
}


let allBooks:any[] =  GetAllBooks();

function GetBooksByCategory(filter:Category):string[]{
    let filteredBooks:string[] = [];

        for(let currbook of allBooks ){
            if(currbook.Category == filter){
                    filteredBooks.push(currbook.Title);
                }
        }            
        return filteredBooks;
}

GetBooksByCategory(Category.Fiction);

// Default Parameters

// function Print(noOfPages:number=100,author:string="unknown",publication:string="Unknown"){
//     console.log(noOfPages,author,publication);
// }
// Print();
// Print(300,'Ranjit Desai');


// Optional Parameters

// function Print(noOfPages:number,author:string,publication?:string){

// }

// REST Parameters  (Allow a function to accept variable number of arguments)


function    Print(noOfPages:number,...restArgs:any[]){
    console.log(restArgs);
}

Print(100);
Print(100,'Ranjit','AW Publication','Pune');



let cars:string[]; // decl
cars = ['BMW','Audi','Honda','Hyundai'];

cars.forEach((c:string)=>console.log(c));



