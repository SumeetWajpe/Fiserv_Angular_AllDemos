let test = 100;

function Add(x:any,y:any){

}