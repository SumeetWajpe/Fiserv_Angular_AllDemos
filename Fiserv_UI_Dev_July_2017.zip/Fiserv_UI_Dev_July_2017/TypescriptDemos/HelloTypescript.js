var x = 100; // type inference
//x = "Hello !";
// type annotations
var y;
y = 200;
var str = "Typescript !";
var boolVar = true;
var z;
z = "ABC";
z = 100;
// Functions
function Add(x, y) {
    return x + y;
}
var result = Add(20, 30);
// Enumerations
var Designations;
(function (Designations) {
    Designations[Designations["Developer"] = 100] = "Developer";
    Designations[Designations["Trainer"] = 200] = "Trainer";
    Designations[Designations["Tester"] = 201] = "Tester";
    Designations[Designations["Manager"] = 202] = "Manager";
    Designations[Designations["Architect"] = 203] = "Architect";
})(Designations || (Designations = {}));
var desgn;
desgn = Designations.Trainer;
//desgn = "Hello !";
console.log(desgn); // numeric Value
console.log(Designations[desgn]); // Symbolic Value
// Arrays
// let cars:string[]; // decl
// cars = ['BMW','Audi','Honda','Hyundai'];
// OR
var moreCars; // Generics
moreCars = new Array('Fiat', 'Merc', 'Ferrari');
// for(let car in cars){
//     console.log(cars[car]);
// }
// for(let car of cars){
//     console.log(car);
// }
var arrayOfObjects;
arrayOfObjects = [
    { Name: 'Fiserv', Location: 'Pune' },
    { Name: 'Accenture', Location: 'Mumbai' },
    { Name: 'Synechron', Location: 'Hyderabad' }
];
for (var _i = 0, arrayOfObjects_1 = arrayOfObjects; _i < arrayOfObjects_1.length; _i++) {
    var company = arrayOfObjects_1[_i];
    console.log(company.Name + " is in " + company.Location);
}
var Category;
(function (Category) {
    Category[Category["Motivational"] = 200] = "Motivational";
    Category[Category["Biography"] = 201] = "Biography";
    Category[Category["Fiction"] = 202] = "Fiction";
})(Category || (Category = {}));
function GetAllBooks() {
    var allBooks;
    allBooks = [
        { Title: 'Playing It My Way', Author: 'Sachin Tendulkar', Available: true, Price: 2000, Category: Category.Biography },
        { Title: 'Wings Of Fire', Author: 'Dr. APJ Abdul Kalam', Available: true, Price: 1000, Category: Category.Motivational },
        { Title: 'Mrutyunjay', Author: 'Ranjit Desai', Available: true, Price: 2000, Category: Category.Fiction },
        { Title: 'Radhey', Author: 'Ranjit Desai', Available: true, Price: 4000, Category: Category.Fiction }
    ];
    return allBooks;
}
var allBooks = GetAllBooks();
function GetBooksByCategory(filter) {
    var filteredBooks = [];
    for (var _i = 0, allBooks_1 = allBooks; _i < allBooks_1.length; _i++) {
        var currbook = allBooks_1[_i];
        if (currbook.Category == filter) {
            filteredBooks.push(currbook.Title);
        }
    }
    return filteredBooks;
}
GetBooksByCategory(Category.Fiction);
// Default Parameters
// function Print(noOfPages:number=100,author:string="unknown",publication:string="Unknown"){
//     console.log(noOfPages,author,publication);
// }
// Print();
// Print(300,'Ranjit Desai');
// Optional Parameters
// function Print(noOfPages:number,author:string,publication?:string){
// }
// REST Parameters  (Allow a function to accept variable number of arguments)
function Print(noOfPages) {
    var restArgs = [];
    for (var _i = 1; _i < arguments.length; _i++) {
        restArgs[_i - 1] = arguments[_i];
    }
    console.log(restArgs);
}
Print(100);
Print(100, 'Ranjit', 'AW Publication', 'Pune');
var cars; // decl
cars = ['BMW', 'Audi', 'Honda', 'Hyundai'];
cars.forEach(function (c) { return console.log(c); });
