module.exports =function(grunt){

   grunt.initConfig({
  uglify: {
    options: {
      mangle: true
    },
    my_target: {
      files: {
        'Dest/output.min.js': ['Source/Math.js']
      }
    }
  }
});

grunt.loadNpmTasks('grunt-contrib-uglify');
grunt.registerTask('default',['uglify']);

}