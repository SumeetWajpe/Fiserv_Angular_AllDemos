var boolVar = false;
var strVar = "Hello !";
var numVar = 100;

/* This is a comment which would not be a part of minification */

function   Add(veryLongX,veryLongY){
    return veryLongX + veryLongY;
}