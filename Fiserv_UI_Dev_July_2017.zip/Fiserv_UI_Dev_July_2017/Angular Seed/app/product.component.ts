import { Component } from '@angular/core';

@Component({
  selector: 'product',
  template: `<h1>I am Product Component !</h1>`,
})
export class ProductComponent  { name = 'Angular'; }
