import { NgModule }      from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import {ProductComponent} from './product.component';
import { AppComponent }  from './app.component';

@NgModule({
  imports:      [ BrowserModule ],
  declarations: [ AppComponent,ProductComponent ],
  bootstrap:    [ AppComponent ]
})
export class AppModule { }
