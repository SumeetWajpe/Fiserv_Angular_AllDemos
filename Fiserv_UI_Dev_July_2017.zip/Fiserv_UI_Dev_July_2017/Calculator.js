var Calculator = (function(){
               var PI = 3.14; // private data
               function Add(x,y){
                    return x + y;
               }
                function Subtract(x,y){
                    //console.log(Add(20,30));  // can use add internally (private)
                    return x - y;
               }
               function Product(x,y){  // private function
                    return x * y;
               }
               return {
                   Addition:Add,
                   Difference:Subtract
               }
           })();// Calling the function immediately