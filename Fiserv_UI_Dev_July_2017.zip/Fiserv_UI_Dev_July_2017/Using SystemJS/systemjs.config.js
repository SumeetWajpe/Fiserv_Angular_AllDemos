(function(global){

    System.config({

        transpiler:'typescript',
        map:{
            app:'app'
        },
        // packages tells SystemJS how to load our modules
        packages:{
            app:{
                main:'./Main.js',
                defaultExtension:'js'
            }
        }
    });


})(this);