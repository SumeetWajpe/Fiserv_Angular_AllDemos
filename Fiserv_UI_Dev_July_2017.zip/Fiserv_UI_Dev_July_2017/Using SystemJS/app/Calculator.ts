

export default class Calculator{
        Add(x:number,y:number):number{
            return x +y;
        }
}



// export function Add(x:number,y:number):number{
//     return x + y;
// }

// export function Subtract(x:number,y:number):number{
//     return x - y;
// }

// export default function Product(x:number,y:number):number{
//     return x * y;
// }