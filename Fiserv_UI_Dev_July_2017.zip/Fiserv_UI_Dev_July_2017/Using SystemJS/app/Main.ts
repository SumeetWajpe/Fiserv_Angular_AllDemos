
//import Product , {Add} from './Calculator'
import Calculator from './Calculator';

let calcObj = new Calculator();


console.log('The addition is : ' +  calcObj.Add(20,30));