"use strict";
exports.__esModule = true;
function Add(x, y) {
    return x + y;
}
exports.Add = Add;
function Subtract(x, y) {
    return x - y;
}
exports.Subtract = Subtract;
