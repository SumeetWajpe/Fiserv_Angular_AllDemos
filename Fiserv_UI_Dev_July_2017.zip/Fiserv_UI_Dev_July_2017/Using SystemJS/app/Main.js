"use strict";
exports.__esModule = true;
var Calculator_1 = require("./Calculator");
console.log('The addition is : ' + Calculator_1.Add(20, 30));
