  basicModule.controller('basicController',function($scope){
                    //$scope.Name = "Fiserv";
                    $scope.CompanyDetails = {
                        Name:'Fiserv Ltd.',
                    Location:'Pune',
                    NoOfEmployees:5000,
                    ImageUrl:'http://www.bankingtech.com/files/2016/03/fiserv.png',
                    TechnologiesUsed:['Typescript','AngularJS','ReactJS','Bootstrap'],
                    isMNC:true
                }
            });