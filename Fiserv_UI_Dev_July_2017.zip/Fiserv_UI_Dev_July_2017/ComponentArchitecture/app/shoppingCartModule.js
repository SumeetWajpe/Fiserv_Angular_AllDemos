var shoppingCartModule =angular.module('shoppingCartModule',[]);

