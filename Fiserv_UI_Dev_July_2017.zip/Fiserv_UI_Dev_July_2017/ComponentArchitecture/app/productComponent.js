shoppingCartModule.component('product',{
    template:'<h3> {{ $ctrl.pDetails.Name}}  </h3>',
    bindings:{
            pDetails:'<'
    }
});