angular
	.module('shoppingCartModule')
	.component('product', {
	    bindings: {
	        product: '<'
	    },        
	    template: [
          '<div>',            
            '<h3>{{$ctrl.product.Name}} </h3>',
          '</div>'
	    ].join('')
	});